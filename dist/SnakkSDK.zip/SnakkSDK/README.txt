Snakk Android SDK
Version 2.0.0

Complete implementation instructions can be found at:
https://github.com/SnakkMedia/Snakk-Android-SDK-Source
